const cube = document.getElementById('cube');
const faces = document.querySelectorAll('.face'); // Select all elements with the class 'face'
let currentFace = 0;

function rotateCube() {
    currentFace = (currentFace + 1) % 6; 
    const angle = currentFace * 90;
    cube.style.transform = `rotateY(${angle}deg)`; 
}

setInterval(rotateCube, 3000); //3000 is 3 secs

faces.forEach((face, index) => {
    face.addEventListener('click', () => {
        currentFace = index;
        const angle = currentFace * 90;
        cube.style.transform = `rotateY(${angle}deg)`;
    });
});
function createDrip() {
    const drip = document.createElement('div');
    drip.classList.add('drip');
    
    drip.style.left = Math.random() * 100 + 'vw'; 
    document.querySelector('.drip-container').appendChild(drip);
    
    setTimeout(() => {
        drip.style.opacity = 2; 
    }, 50);

    drip.addEventListener('animationend', () => {
        drip.remove();
    });
}

setInterval(createDrip, 1000);
